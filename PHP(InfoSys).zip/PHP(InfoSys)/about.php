<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>About</title>
<style type="text/css">

</style>
</head>

<body background="1.gif" text="white">

<br />
<br />
<br />
<table align="center" cellpadding="0" background="mdgraphs-ocean-breeze.jpg" width="800" border="3">
  <tr>
    <td><p align="center"><img src="" width="155" height="90" border="0" align="bottom" /></p>
      <table align="center" width="759" border="0">
        <tr>
          <td width="160" height="287">&nbsp;</td>
          <td valign="top" width="589"><ul>
          
            <ul>
			 <li><strong><B>ABOUT:</B></strong>:</li><br>
              <li><b>Simple Enrollment System</b><br /><br>
              </li>
              </ul>
            
            <ul>
          
              </li>
              <li><strong>School: </strong>- - - - - </li>
            
            </ul>
        
		   
		     </ul>
		  </td>
        </tr>
      </table>
<table width="70%" align="center">
<tr>
  <td>&nbsp;</td>
</tr>
<tr>
  <td>&nbsp;</td>
</tr>
</table>
      <p align="center"><a href="admin/index.php"><img width="95" height="50" border="0" src="cooltext457954941MouseOver.png" onmouseover="this.src='cooltext457954941.png';" onmouseout="this.src='cooltext457954941MouseOver.png';" /></a> 
	  <a href="home.php"><img src="cooltext457951615MouseOver.PNG" onmouseover="this.src='cooltext457951615.png';" onmouseout="this.src='cooltext457951615MouseOver.PNG';"width="95" height="50" border="0" align="bottom"></a>
	  <a href="logout.php"><img src="cooltext4579.PNG" onmouseover="this.src='cooltext457955210.png';" onmouseout="this.src='cooltext4579.PNG';"width="95" height="50" border="0" align="bottom" /></a></p>
      <center>
       
      </center>
    <p align="left"><a href="home.php"></a></p></td>
  </tr>
</table>
<h1 align="center" class="heading">&nbsp;</h1>
</body>
</html>
