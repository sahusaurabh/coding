<?php
$host = "localhost";
$user = "root";
$pass ="";
$dbase ="department";

$con = mysql_connect($host,$user,$pass);
mysql_select_db($dbase,$con);

?>