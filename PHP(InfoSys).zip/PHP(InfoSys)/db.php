<?php	

mysql_connect("localhost","root","") or die("could not connect to database");
mysql_select_db("department") or die ("could not select database");
?>
