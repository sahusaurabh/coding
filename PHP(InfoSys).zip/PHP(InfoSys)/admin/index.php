<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Simple Enrollment System</title>
<style type="text/css">

</style>
</head>

<body background="1.gif" text="white">
<br />
<br />
<br />
<!-- <!--<table align="center" cellpadding="0" background="AquaLoop Wallpaper Bk.jpg" width="800" border="0">  -->
<table align="center" border=3 CellPadding=5  border="white" background="Copy of mdgraphs-ocean-breeze.jpg" WIDTH=10% text="blue" >
<center> 
 <tr>
    <td><h1 align="center" class="heading"><img width="747" height="58" border="0" src="cooltext457948700.png" /></h1>
      <p align="center">&nbsp;</p>
      <table width="638" border="0" align="center">
        <tr>
          <td width="107"><a href="insert.php"><img src="cooltext457947887MouseOver.PNG" onmouseover="this.src='cooltext457947887.png';" onmouseout="this.src='cooltext457947887MouseOver.PNG';"width="95" height="50" border="0" align="bottom"></a></td>
          <td width="515" class="options"><b>New Record of Student</td>
        </tr>
        <tr>
          <td><a href="delete.php"><img src="cooltext457947999MouseOver.PNG" onmouseover="this.src='cooltext457947999.png';" onmouseout="this.src='cooltext457947999MouseOver.PNG';"width="95" height="50" border="0" align="bottom"></a></td>
          <td class="options"><b>Delete Record of Student</td>
        </tr>
        <tr>
          <td><a href="modify.php"><img src="cooltext457948094MouseOver.PNG"onmouseover="this.src='cooltext457948094.png';" onmouseout="this.src='cooltext457948094MouseOver.PNG';"width="95" height="50" border="0" align="bottom"></a></td>
          <td class="options"><b>Update Record of Student</td>
        </tr>
      </table>
      <p align="right"><a href="../about.php"><img src="cooltext457954859MouseOver.PNG" onmouseover="this.src='cooltext457954859.png';" onmouseout="this.src='cooltext457954859MouseOver.PNG';"width="95" height="50" border="0" align="bottom"></a>
	  
	   <a href="../home.php"><img src="cooltext457951615MouseOver.PNG" onmouseover="this.src='cooltext457951615.png';" onmouseout="this.src='cooltext457951615MouseOver.PNG';"width="95" height="50" border="0" align="bottom"></a>
	   <a href="../logout.php"><img src="cooltext457955210MouseOver.PNG" onmouseover="this.src='cooltext457955210.png';" onmouseout="this.src='cooltext457955210MouseOver.PNG';"width="95" height="50" border="0" align="bottom"></a></p></p>
    <p align="center"><a href="../about.php"></a></p></td>
  </tr>
</table>
<h1 align="center" class="heading">&nbsp;</h1>
	 
	 <!-- <a href="../"><img border="0" src="images/cooltext457951462.png" alt="Go Back" onmouseover="this.src='images/cooltext457951462MouseOver.png';" onmouseout="this.src='images/cooltext457951462.png';" /></a> -->
	  
</body>
</html>